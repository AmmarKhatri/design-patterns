package org.example;

public interface Button {
    Button render(); //prints a button
}
